/// <reference path="../managers/game.ts"/>
/// <reference path="../../Scripts/objects/label.ts"/>
/// <reference path="../../Scripts/objects/button.ts"/>
/// <reference path="../../Scripts/config/scene.ts"/>
/// <reference path="../../Scripts/objects/scene.ts"/>
/// <reference path="../../Scripts/objects/image.ts"/>

/// <reference path="../../Scripts/scenes/start.ts"/>