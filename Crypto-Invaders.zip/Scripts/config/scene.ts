module config {
    export enum Scene {
        INTRO,
        START,
        OPTIONS,
        HELP,
        INFO,
        GAME,
        OVER   
    }
}