module config {
    export enum Difficulty {
        NORMAL,
        HARD,
        Hell
    }
}