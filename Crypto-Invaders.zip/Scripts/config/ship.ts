module config {
    export enum Ship {
        Botcoin,
        Lightcoin,
        Enderium
    }
}