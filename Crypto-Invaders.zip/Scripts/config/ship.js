var config;
(function (config) {
    var Ship;
    (function (Ship) {
        Ship[Ship["Botcoin"] = 0] = "Botcoin";
        Ship[Ship["Lightcoin"] = 1] = "Lightcoin";
        Ship[Ship["Enderium"] = 2] = "Enderium";
    })(Ship = config.Ship || (config.Ship = {}));
})(config || (config = {}));
//# sourceMappingURL=ship.js.map