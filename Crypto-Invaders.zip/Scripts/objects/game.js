var objects;
(function (objects) {
    var Game = /** @class */ (function () {
        function Game() {
        }
        return Game;
    }());
    objects.Game = Game;
})(objects || (objects = {}));
//# sourceMappingURL=game.js.map